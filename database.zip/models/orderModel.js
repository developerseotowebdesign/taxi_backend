import mongoose from "mongoose";

const orderSchema = mongoose.Schema({

  status: {
    type: String,
  },
  pickupTime: {
    type: String,
  },
  pickupDate: {
    type: String,
  },
  bookingTyp: {
    type: String,
  },  
  rideTyp: {
    type: String,
  },
  PickupLocation: {
    type: String,
  },
  PickupAddress: {
    type: String,
  }, 
  DestinationLocation: {
    type: String,
  },
  DestinationAddress: {
    type: String,
  },
  BookingDistance: {
    type: String,
  },
  TripStart: {
    type: String,
  },
  TripEnd: {
    type: String,
  },
  CarType: {
    type: String,
  },
  mode: {
    type: String,
  },
  details: {
    type: Array,
  },
  discount: {
    type: String,
  },
  shipping: {
    type: String,
  },
  CarType: {
    type: String,
  },
  totalAmount: {
    required: [true, "Total Amount is required"],
    type: Number,
  },
  userId: [{  // Changed field name to plural and set type as an array of ObjectIds
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  }],
  driverId: [{  // Changed field name to plural and set type as an array of ObjectIds
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],
  primary: {
    type: String,
  }, payment: {
    type: Number,
    default: 0,
  },
  orderId: {
    type: Number,
  },
  reason: {
    type: String,
  },
  comment: {
    type: String,
  },
},
  { timestamps: true }
);

const orderModel = mongoose.model('Order', orderSchema);

export default orderModel;